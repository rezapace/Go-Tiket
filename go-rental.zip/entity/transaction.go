package entity

import "time"

type Transaction struct {
	ID        int64
	RenterID  int64
	MotorID   int64
	StartDate time.Time
	EndDate   time.Time
	TotalCost float64
	Status    string
	AdminFee  float64
	CreatedAt time.Time // Add CreatedAt field
	UpdatedAt time.Time // Add UpdatedAt field
}

func NewTransaction(renterID int64, motorID int64, startDate, endDate time.Time, totalCost, adminFee float64, status string) *Transaction {
	return &Transaction{
		RenterID:  renterID,
		MotorID:   motorID,
		StartDate: startDate,
		EndDate:   endDate,
		TotalCost: totalCost,
		Status:    status,
		AdminFee:  adminFee,
	}
}