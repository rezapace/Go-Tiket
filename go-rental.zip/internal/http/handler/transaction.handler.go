package handler

import (
	"net/http"
	"time"

	"Rental/entity"
	"Rental/common"
	"Rental/internal/http/validator"
	"Rental/internal/service"

	"github.com/golang-jwt/jwt/v5"
	"github.com/labstack/echo/v4"
)

type TransactionHandler struct {
	transactionService service.TransactionUseCase
	paymentService     service.PaymentUseCase
	userService        service.UserUsecase
}

func NewTransactionHandler(transactionService service.TransactionUseCase, paymentService service.PaymentUseCase, userService service.UserUsecase) *TransactionHandler {
	return &TransactionHandler{
		transactionService: transactionService,
		paymentService:     paymentService,
		userService:        userService,
	}
}

func (h *TransactionHandler) CreateTransaction(c echo.Context) error {
	var req struct {
		RenterID  int64     `json:"renter_id"`
		MotorID   int64     `json:"motor_id"`
		StartDate time.Time `json:"start_date"`
		EndDate   time.Time `json:"end_date"`
		TotalCost float64   `json:"total_cost"`
		AdminFee  float64   `json:"admin_fee"`
		Status    string    `json:"status"`
	}

	if err := c.Bind(&req); err != nil {
		return c.JSON(http.StatusBadRequest, common.NewErrorResponse("Invalid request payload"))
	}

	transaction := entity.NewTransaction(req.RenterID, req.MotorID, req.StartDate, req.EndDate, req.TotalCost, req.AdminFee, req.Status)
	transaction.CreatedAt = time.Now()
	transaction.UpdatedAt = time.Now()

	// Assuming transactionService has a method to save the transaction
	if err := h.transactionService.CreateTransaction(transaction); err != nil {
		return c.JSON(http.StatusInternalServerError, common.NewErrorResponse("Failed to create transaction"))
	}

	return c.JSON(http.StatusCreated, transaction)
}